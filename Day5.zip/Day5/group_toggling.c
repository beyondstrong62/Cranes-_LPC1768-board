
#include <LPC17xx.h>
 // LEDs connected from P1.19 to P1.26
#define ALL_LED (0xFF << 19)
#define GROUP1 (0x0F << 19)
#define GROUP2 (0x0F << 23)
void delay_ms(uint32_t millis);


int main(void)
{
    //uint32_t i;

    // Configure P1.19 - P1.26 as output pins

    LPC_GPIO1->FIODIR |= ALL_LED; // Set P1.19 to P1.26 as outp
	LPC_GPIO1->FIOCLR = ALL_LED;

    while (1) {
            LPC_GPIO1->FIOSET = GROUP1;
			LPC_GPIO1->FIOCLR = GROUP2; 
        delay_ms(5);
      LPC_GPIO1->FIOSET = GROUP2;
	  LPC_GPIO1->FIOCLR = GROUP1; 
	  delay_ms(5);   
    }
}

void delay_ms(uint32_t millis)
{
    uint32_t i, j;
    for (i = 0; i < millis; i++) {
        for (j = 0; j < 1250; j++) {
            // Small time delay loop
        }
    }
}
