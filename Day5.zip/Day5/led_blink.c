//write LPC1768 c to blionk LED CONNECTED TO  p1.19PIN
//FOREVER
#include <LPC17xx.h>
#define LED1 (0x01 << 19)

int main()
{
int i;
//CONFIGURE p1.19 PIN AS OUTPUT PIN
LPC_GPIO1->FIODIR |= LED1 ;
	//
while(1){
	LPC_GPIO1->FIOSET=LED1;	//turn on LED
	for(i=0;i<100000;i++){}
	LPC_GPIO1->FIOCLR=LED1; //turn off LED
	for(i=0;i<100000;i++){}
}
}
