#include <LPC17xx.h>

#define ALL_LED (0xFF << 19) // Define all LEDs connected from P1.19 to P1.26

void delay_ms(uint32_t millis);

int main(void)
{
    uint32_t i, mid = 22; // Center LED index (P1.22 is the midpoint for P1.19 to P1.26)

    // Configure P1.19 - P1.26 as output pins
    LPC_GPIO1->FIODIR |= ALL_LED; // Set P1.19 to P1.26 as outputs
    LPC_GPIO1->FIOCLR = ALL_LED;  // Turn off all LEDs initially

    while (1) {
        // Converging effect: LEDs light up from outer edges to the center
        for (i = 0; i <= (mid - 19); i++) {
            LPC_GPIO1->FIOSET = (1 << (19 + i)) | (1 << (26 - i)); // Turn on symmetrical LEDs
            delay_ms(50); // Delay for convergence
        }

        delay_ms(50); // Hold all LEDs ON at the center

        // Diverging effect: LEDs light up from the center outward (reverse of converging)
        for (i = 0; i <= (mid - 19); i++) {
            LPC_GPIO1->FIOCLR = (1 << (mid - i)) | (1 << (mid + i)); // Turn off LEDs symmetrically inward
            delay_ms(50); // Delay for divergence (moving outward)
        }

        delay_ms(300); // Hold all LEDs OFF after divergence

        // Reset LEDs to OFF before restarting the cycle
        LPC_GPIO1->FIOCLR = ALL_LED;
        delay_ms(50); // Brief pause before the next cycle
    }
}

void delay_ms(uint32_t millis)
{
    uint32_t i, j;
    for (i = 0; i < millis; i++) {
        for (j = 0; j < 1250; j++) {
            // Small time delay loop
        }
    }
}
