											#include <LPC17xx.h>

#define ALL_LED (0xFF << 19) // LEDs connected from P1.19 to P1.26

void delay_ms(uint32_t millis);

int main(void)
{
    uint32_t i;

    // Configure P1.19 - P1.26 as output pins
    LPC_GPIO1->FIODIR |= ALL_LED; // Set P1.19 to P1.26 as outputs
    LPC_GPIO1->FIOCLR = ALL_LED;  // Turn off all LEDs initially

    while (1) {
        // Pattern 1: Flowing wave (forward and backward)
        for (i = 19; i <= 26; i++) {
            LPC_GPIO1->FIOSET = (1 << i);  // Turn on current LED
            delay_ms(100);                // Short delay
            LPC_GPIO1->FIOCLR = (1 << i); // Turn off current LED
        }
        for (i = 26; i >= 19; i--) {
            LPC_GPIO1->FIOSET = (1 << i);  // Turn on current LED
            delay_ms(100);                // Short delay
            LPC_GPIO1->FIOCLR = (1 << i); // Turn off current LED
        }

        // Pattern 2: Pulsating (all LEDs on/off in sequence)
        for (i = 0; i < 5; i++) {
            LPC_GPIO1->FIOSET = ALL_LED; // Turn on all LEDs
            delay_ms(50);              // Short delay
            LPC_GPIO1->FIOCLR = ALL_LED; // Turn off all LEDs
            delay_ms(50);
        }

        // Pattern 3: Alternating wave (even and odd LEDs)
        for (i = 19; i <= 26; i += 2) {
            LPC_GPIO1->FIOSET = (1 << i); // Turn on even LEDs
        }
        delay_ms(50);
        LPC_GPIO1->FIOCLR = ALL_LED; // Turn off all LEDs
        for (i = 20; i <= 26; i += 2) {
            LPC_GPIO1->FIOSET = (1 << i); // Turn on odd LEDs
        }
        delay_ms(50);
        LPC_GPIO1->FIOCLR = ALL_LED;

        // Pattern 4: Chasing pairs (two LEDs at a time)
        for (i = 19; i <= 25; i++) {
            LPC_GPIO1->FIOSET = (1 << i) | (1 << (i + 1)); // Turn on two consecutive LEDs
            delay_ms(50);                                // Short delay
            LPC_GPIO1->FIOCLR = (1 << i) | (1 << (i + 1)); // Turn off the same LEDs
        }

        // Pattern 5: Back-and-forth fade effect (increasing/decreasing intensity)
        for (i = 19; i <= 26; i++) {
            LPC_GPIO1->FIOSET = (1 << i);  // Gradually light up LEDs
            delay_ms(50);
        }
        delay_ms(200); // Hold the LEDs for a moment
        for (i = 26; i >= 19; i--) {
            LPC_GPIO1->FIOCLR = (1 << i); // Gradually turn off LEDs
            delay_ms(50);
        }
    }
}

void delay_ms(uint32_t millis)
{
    uint32_t i, j;
    for (i = 0; i < millis; i++) {
        for (j = 0; j < 1250; j++) {
            // Small time delay loop
        }
    }
}
