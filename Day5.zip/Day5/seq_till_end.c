#include <LPC17xx.h>

#define ALL_LED (0xFF << 19)    // Define all LEDs connected from P1.19 to P1.26

void delay_ms(uint32_t millis);

int main(void)
{
    uint32_t i;  // Declare the loop variable at the beginning of the block

    // Configure P1.19 - P1.26 as output pins
    LPC_GPIO1->FIODIR |= ALL_LED; // Set P1.19 to P1.26 as outputs
    LPC_GPIO1->FIOCLR = ALL_LED;  // Turn off all LEDs initially

    while (1) {
        // First phase: Sequentially light up LEDs from P1.19 to P1.26
        for (i = 19; i <= 26; i++) {
            LPC_GPIO1->FIOSET = (1 << i);      // Turn on the current LED
            delay_ms(200);                     // 200 ms delay
        }

        // Second phase: Sequentially light up LEDs from P1.26 to P1.19
        for (i = 26; i >= 19; i--) {
            LPC_GPIO1->FIOSET = (1 << i);      // Turn on the current LED
            delay_ms(200);                     // 200 ms delay
        }

        // Brief pause before restarting the cycle
        LPC_GPIO1->FIOCLR = ALL_LED;
        delay_ms(500); // 500 ms delay before starting again
    }
}

void delay_ms(uint32_t millis)
{
    uint32_t i, j;
    for (i = 0; i < millis; i++) {
        for (j = 0; j < 1250; j++) {
            // Small time delay loop
        }
    }
}
