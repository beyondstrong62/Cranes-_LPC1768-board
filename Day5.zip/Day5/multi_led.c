#include <LPC17xx.h>

#define LED1 (0x01 << 19)       // Define LED1 connected to P1.19
#define ALL_LED (0xFF << 19)    // Define all LEDs connected from P1.19 to P1.26

void delay_ms(uint32_t millis);

int main(void)
{
    // Configure P1.19 - P1.26 as output pins
    LPC_GPIO1->FIODIR |= ALL_LED; // Set P1.19 to P1.26 as outputs
    LPC_GPIO1->FIOCLR = ALL_LED;  // Turn off all LEDs initially

    while (1) {
        LPC_GPIO1->FIOSET = ALL_LED;  // Turn on all LEDs
        delay_ms(1000);               // 1-second delay
        LPC_GPIO1->FIOCLR = ALL_LED;  // Turn off all LEDs
        delay_ms(1000);               // 1-second delay
    }
}

void delay_ms(uint32_t millis)
{
    uint32_t i, j;
    for (i = 0; i < millis; i++) {
        for (j = 0; j < 1250; j++) {
            // Small time delay loop
        }
    }
}
